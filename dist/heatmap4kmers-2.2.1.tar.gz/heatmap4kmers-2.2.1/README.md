# HeatMap4kmeRs

[HeatMap4kmeRs](https://pypi.org/project/heatmap4kmers/) the visualization package recommended for [kmeRs package](https://github.com/urniaz/kmeRs). 

## Installation

```python

# Install from PyPI 

pip install heatmap4kmers

```

## Documentation and tutorials 

The documentation and tutorials are included in the package.
